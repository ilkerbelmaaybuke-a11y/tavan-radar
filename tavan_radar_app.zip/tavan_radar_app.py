# ===========================================
# 📈 TAVAN RADAR - BIST HİSSE TARAYICI (v1.0)
# ===========================================

import yfinance as yf
import pandas as pd
import numpy as np
import ta
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
import streamlit as st

# --- Sayfa ayarları ---
st.set_page_config(page_title="🚀 Tavan Radar", layout="wide")
st.title("🚀 Tavan Radar — BIST Gerçek Zamanlı Tarama")
st.write("Makine öğrenmesi + teknik analizle tavan potansiyelli hisseleri bulur.")

# --- Parametreler ---
TICKERS = ["THYAO.IS","ASELS.IS","KRDMD.IS","SASA.IS","HEKTS.IS",
           "EREGL.IS","TUPRS.IS","PETKM.IS","BIMAS.IS","ISCTR.IS"]
PERIOD, INTERVAL = "2y", "1d"
FUTURE_DAYS, TARGET_GAIN = 5, 10.0

# --- Fonksiyonlar ---
@st.cache_data
def add_indicators(df):
    df['rsi'] = ta.momentum.RSIIndicator(df['Close'], 14).rsi()
    macd = ta.trend.MACD(df['Close'])
    df['macd_hist'] = macd.macd_diff()
    df['ema50'] = ta.trend.EMAIndicator(df['Close'], 50).ema_indicator()
    df['ema200'] = ta.trend.EMAIndicator(df['Close'], 200).ema_indicator()
    df['trend_ok'] = (df['ema50'] > df['ema200']).astype(int)
    df['vol_ratio'] = df['Volume'] / df['Volume'].rolling(20).mean()
    df['atr'] = ta.volatility.AverageTrueRange(df['High'], df['Low'], df['Close']).average_true_range()
    df.dropna(inplace=True)
    return df

@st.cache_data
def fetch_data(ticker):
    df = yf.download(ticker, period=PERIOD, interval=INTERVAL, progress=False)
    if df.empty: return None
    df = add_indicators(df)
    df['future_max'] = df['Close'].shift(-FUTURE_DAYS).rolling(FUTURE_DAYS).max()
    df['gain_pct'] = (df['future_max']/df['Close'] - 1)*100
    df['target'] = (df['gain_pct'] >= TARGET_GAIN).astype(int)
    return df.dropna()

# --- Veri çekimi ---
st.info("📡 Borsa verileri yükleniyor... Lütfen bekleyin ⏳")
frames=[]
for t in TICKERS:
    d=fetch_data(t)
    if d is not None:
        d['ticker']=t
        frames.append(d)
data=pd.concat(frames)

# --- Makine öğrenmesi modeli ---
features=['rsi','macd_hist','vol_ratio','atr','trend_ok']
X,y=data[features],data['target']
X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=0.2,random_state=42)
model=RandomForestClassifier(n_estimators=150,max_depth=8,class_weight='balanced',random_state=42)
model.fit(X_train,y_train)
acc=accuracy_score(y_test,model.predict(X_test))
st.success(f"🎯 Model doğruluk oranı: {acc*100:.2f}%")

# --- Son tahminler ---
latest=[]
for t in TICKERS:
    df=fetch_data(t)
    if df is None: continue
    last=df.iloc[-1]
    prob=model.predict_proba(df[features].tail(1))[0][1]*100
    score=0
    if last['rsi']<40: score+=2
    if last['macd_hist']>0: score+=2
    if last['vol_ratio']>1.5: score+=2
    if last['trend_ok']==1: score+=2
    if prob>70: score+=2
    latest.append({
        "Hisse":t,
        "Kapanış":round(last['Close'],2),
        "RSI":round(last['rsi'],1),
        "MACD":round(last['macd_hist'],3),
        "Hacim Oranı":round(last['vol_ratio'],2),
        "Trend": "Yükselen" if last['trend_ok']==1 else "Zayıf",
        "Tavan Olasılığı %":round(prob,1),
        "Radar Skoru":score
    })

df_latest=pd.DataFrame(latest).sort_values("Tavan Olasılığı %",ascending=False)

st.subheader("📊 Güncel Radar Sonuçları")
st.dataframe(df_latest, use_container_width=True)

st.caption("🟢 Radar Skoru ≥ 8 → Güçlü sinyal | 🟡 5–7 → Orta | 🔴 <5 → Zayıf")
